import { Injectable } from '@nestjs/common';
import { UsersService } from '../users/users.service';

@Injectable()
export class AuthService {
  constructor(private usersService: UsersService) {}

  async validateUser(email: string, password: string) {
    const user = await this.usersService.findByEmail(email);
    if (!user) return null;
    if (user.password === password) {
      // omit password in returned object
      const { password: _, ...rest } = user as any;
      return rest;
    }
    return null;
  }
}
