import { Controller, Get, Post, Body } from '@nestjs/common';
import { ProductsService } from './products.service';

@Controller('products')
export class ProductsController {
  constructor(private svc: ProductsService) {}

  @Get()
  async list() {
    const items = await this.svc.findAll();
    return { ok: true, items };
  }

  @Post()
  async create(@Body() body: { codigo: string; nombre: string }) {
    const prod = await this.svc.create(body);
    return { ok: true, product: prod };
  }
}
