# Mascotas API - Skeleton

Proyecto de ejemplo: API NestJS que usa MySQL/MariaDB para usuarios y MongoDB para productos/pets.

## Qué incluye
- Estructura mínima de NestJS (módulos: users, auth, products)
- Docker Compose para MariaDB + MongoDB local
- SQL de ejemplo para crear tabla `users`
- Archivos .ts listos para pegar en un proyecto NestJS

## Uso
1. Copia este proyecto a tu máquina.
2. Instala dependencias: `npm install`
3. Levanta bases con Docker: `docker-compose up -d`
4. Configura `.env` con credenciales (puedes usar `.env.example`)
5. Inicia la app: `npm run start:dev`

## Endpoints
- POST /auth/login  -> { email, password }
- GET  /products
- POST /products -> { codigo, nombre }

Nota: Las contraseñas se almacenan en texto plano SOLO para demostraciones.
