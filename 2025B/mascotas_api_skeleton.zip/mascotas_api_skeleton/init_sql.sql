CREATE DATABASE IF NOT EXISTS mascotas_db;
USE mascotas_db;

CREATE TABLE IF NOT EXISTS users (
  id CHAR(36) PRIMARY KEY,
  name VARCHAR(150) NOT NULL,
  email VARCHAR(200) NOT NULL UNIQUE,
  password VARCHAR(200) NOT NULL,
  role VARCHAR(50),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert ejemplo (password en texto plano)
INSERT INTO users (id, name, email, password, role)
VALUES ('11111111-1111-1111-1111-111111111111', 'Brayan Rubio', 'brayan@example.com', 'mi_password_secreto', 'user')
ON DUPLICATE KEY UPDATE email=email;
